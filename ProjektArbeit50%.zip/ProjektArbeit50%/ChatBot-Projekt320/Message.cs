﻿namespace ChatBotApp
{
    public class Message
    {
        public string Keyword { get; set; }
        public string Answer { get; set; }
    }
}
