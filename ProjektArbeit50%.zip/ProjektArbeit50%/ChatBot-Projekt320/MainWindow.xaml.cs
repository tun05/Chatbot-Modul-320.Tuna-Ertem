﻿using System;
using System.Windows;
using System.IO;
using Microsoft.Win32;

namespace ChatBotApp
{
    public sealed partial class MainWindow : Window
    {
        private BotEngine botEngine;
        private string logFilePath = @"C:\Users\erzincansivas\Documents\Modul320\ProjektArbeit50%\ChatBot-Projekt320\chatlog.txt"; // Pfad zur Logdatei

        public MainWindow()
        {
            InitializeComponent();

            string[] filePaths = {
                @"C:\Users\erzincansivas\Documents\Modul320\ProjektArbeit50%\ChatBot-Projekt320\keywords.txt",
                @"C:\Users\erzincansivas\Documents\Modul320\ProjektArbeit50%\ChatBot-Projekt320\additional_keywords.txt"
            };

            IStorage storage = new TextFileStorage(filePaths);
            botEngine = new BotEngine(storage);
        }

        private void SendMessage_Click(object sender, RoutedEventArgs e)
        {
            string userMessage = UserInput.Text.Trim();

            if (string.IsNullOrEmpty(userMessage))
            {
                MessageBox.Show("Nachricht darf nicht leer sein!", "Fehler", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Nachricht des Benutzers anzeigen und protokollieren
            ChatDisplay.AppendText("User: " + userMessage + Environment.NewLine);
            LogMessage("User: " + userMessage);
            UserInput.Clear();

            // Antwort vom Bot erhalten und anzeigen
            string botResponse = botEngine.GetAnswer(userMessage);
            ChatDisplay.AppendText("Bot: " + botResponse + Environment.NewLine);
            LogMessage("Bot: " + botResponse);
        }

        private void LogMessage(string message)
        {
            // Nachricht in die Logdatei schreiben
            using (StreamWriter writer = new StreamWriter(logFilePath, true))
            {
                writer.WriteLine($"{DateTime.Now}: {message}");
            }
        }

        private void OpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";

            if (openFileDialog.ShowDialog() == true)
            {
                string newFilePath = openFileDialog.FileName;
                IStorage storage = new TextFileStorage(new[] { newFilePath });
                botEngine = new BotEngine(storage);
                MessageBox.Show("Neue Datei geladen!", "Info", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void CloseApp_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
