﻿using System.Collections.Generic;

namespace ChatBotApp
{
    public interface IStorage
    {
        List<Message> LoadMessages();
        void SaveMessage(Message message);
    }
}
