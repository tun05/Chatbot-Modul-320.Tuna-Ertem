﻿using System;
using System.Collections.Generic;
using System.IO;

namespace ChatBotApp
{
    public class TextFileStorage : IStorage
    {
        private string[] filePaths;

        public TextFileStorage(string[] filePaths)
        {
            this.filePaths = filePaths;
        }

        public IStorage IStorage
        {
            get => default;
            set
            {
            }
        }

        public List<Message> LoadMessages()
        {
            List<Message> messages = new List<Message>();

            foreach (var filePath in filePaths)
            {
                try
                {
                    if (File.Exists(filePath))
                    {
                        var lines = File.ReadAllLines(filePath);
                        foreach (var line in lines)
                        {
                            var parts = line.Split(';');
                            if (parts.Length == 2)
                            {
                                messages.Add(new Message { Keyword = parts[0].Trim(), Answer = parts[1].Trim() });
                            }
                            else
                            {
                                throw new FormatException($"Ungültiges Format in Datei: {filePath}. Zeile: {line}");
                            }
                        }
                    }
                    else
                    {
                        throw new FileNotFoundException($"Schlüsselwort-Datei {filePath} nicht gefunden.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Fehler beim Laden der Datei {filePath}: {ex.Message}");
                }
            }

            return messages;
        }

        public void SaveMessage(Message message)
        {
            foreach (var filePath in filePaths)
            {
                try
                {
                    using (StreamWriter writer = new StreamWriter(filePath, true))
                    {
                        writer.WriteLine($"{message.Keyword};{message.Answer}");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Fehler beim Speichern in die Datei {filePath}: {ex.Message}");
                }
            }
        }
    }
}
