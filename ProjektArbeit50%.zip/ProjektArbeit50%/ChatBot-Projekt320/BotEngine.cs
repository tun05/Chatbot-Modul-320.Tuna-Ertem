﻿using System;
using System.Collections.Generic;

namespace ChatBotApp
{
    /// <summary>
    /// Diese Klasse repräsentiert die Hauptlogik des Chatbots, um Schlüsselwörter zu verarbeiten und Antworten zu geben.
    /// </summary>
    public class BotEngine
    {
        private IStorage storage;
        private Dictionary<string, string> keywordDictionary;

        /// <summary>
        /// Konstruktor für die BotEngine.
        /// </summary>
        /// <param name="storage">Speicherklasse, die die Schlüsselwörter und Antworten lädt und speichert.</param>
        public BotEngine(IStorage storage)
        {
            this.storage = storage;
            keywordDictionary = new Dictionary<string, string>();
            LoadMessages();
        }









        /// <summary>
        /// Lädt die Nachrichten aus der Speicherklasse.
        /// </summary>
        private void LoadMessages()
        {
            keywordDictionary.Clear();
            var messages = storage.LoadMessages();
            foreach (var message in messages)
            {
                keywordDictionary[message.Keyword.ToLower()] = message.Answer;
            }
        }

        /// <summary>
        /// Gibt die Antwort basierend auf dem eingegebenen Schlüsselwort zurück.
        /// </summary>
        /// <param name="keyword">Das eingegebene Schlüsselwort.</param>
        /// <returns>Die Antwort auf das Schlüsselwort oder einen Vorschlag, falls es nicht gefunden wird.</returns>
        public string GetAnswer(string keyword)
        {
            keyword = keyword.ToLower();
            if (keywordDictionary.ContainsKey(keyword))
            {
                return keywordDictionary[keyword];
            }
            else
            {
                return GetSuggestion(keyword);
            }
        }

        /// <summary>
        /// Fügt ein neues Schlüsselwort mit einer Antwort hinzu.
        /// </summary>
        /// <param name="keyword">Das neue Schlüsselwort.</param>
        /// <param name="answer">Die Antwort auf das Schlüsselwort.</param>
        public void AddKeyword(string keyword, string answer)
        {
            if (!keywordDictionary.ContainsKey(keyword.ToLower()))
            {
                keywordDictionary[keyword.ToLower()] = answer;
                storage.SaveMessage(new Message { Keyword = keyword, Answer = answer });
            }
        }

        /// <summary>
        /// Gibt eine alternative Antwort, wenn das eingegebene Schlüsselwort nicht gefunden wird.
        /// </summary>
        /// <param name="userInput">Das eingegebene Wort.</param>
        /// <returns>Ein Vorschlag für ein ähnliches Schlüsselwort.</returns>
        private string GetSuggestion(string userInput)
        {
            string bestMatch = null;
            int lowestDistance = int.MaxValue;

            foreach (var keyword in keywordDictionary.Keys)
            {
                int distance = LevenshteinDistance(userInput, keyword);
                if (distance < lowestDistance)
                {
                    lowestDistance = distance;
                    bestMatch = keyword;
                }
            }

            if (lowestDistance <= 2)
            {
                return $"Meintest du: {bestMatch}?";
            }

            return "Schlüsselwort nicht gefunden.";
        }

        /// <summary>
        /// Berechnet die Levenshtein-Distanz zwischen zwei Zeichenfolgen, um die Ähnlichkeit zu bestimmen.
        /// </summary>
        /// <param name="s">Erste Zeichenfolge.</param>
        /// <param name="t">Zweite Zeichenfolge.</param>
        /// <returns>Die Anzahl der Bearbeitungsschritte, um eine Zeichenfolge in die andere zu verwandeln.</returns>
        private int LevenshteinDistance(string s, string t)
        {
            int n = s.Length;
            int m = t.Length;
            int[,] d = new int[n + 1, m + 1];

            for (int i = 0; i <= n; d[i, 0] = i++) { }
            for (int j = 0; j <= m; d[0, j] = j++) { }

            for (int i = 1; i <= n; i++)
            {
                for (int j = 1; j <= m; j++)
                {
                    int cost = (t[j - 1] == s[i - 1]) ? 0 : 1;
                    d[i, j] = Math.Min(Math.Min(d[i - 1, j] + 1, d[i, j - 1] + 1), d[i - 1, j - 1] + cost);
                }
            }
            return d[n, m];
        }
    }
}
