using System.Collections.Generic;
using Xunit;

namespace ChatBot_Projekt320
{
    // Message-Klasse
    public class Message
    {
        public string Keyword { get; set; }
        public string Answer { get; set; }
    }

    // IStorage-Schnittstelle
    public interface IStorage
    {
        List<Message> LoadMessages();
        void SaveMessage(Message message);
    }

    // BotEngine-Klasse
    public class BotEngine
    {
        private IStorage storage;
        private Dictionary<string, string> keywordDictionary = new Dictionary<string, string>();

        public BotEngine(IStorage storage)
        {
            this.storage = storage;
            LoadMessages();
        }

        public string GetAnswer(string keyword)
        {
            if (keywordDictionary.ContainsKey(keyword))
            {
                return keywordDictionary[keyword];
            }
            else
            {
                return "Entschuldigung, ich kenne dieses Schl�sselwort nicht.";
            }
        }

        private void LoadMessages()
        {
            var messages = storage.LoadMessages();
            foreach (var message in messages)
            {
                keywordDictionary[message.Keyword] = message.Answer;
            }
        }
    }

    // MockStorage-Klasse f�r die Tests
    public class MockStorage : IStorage
    {
        public List<Message> LoadMessages()
        {
            // Simulierte Daten f�r den Test
            return new List<Message>
            {
                new Message { Keyword = "hallo", Answer = "Hallo! Wie kann ich Ihnen helfen?" }
            };
        }

        public void SaveMessage(Message message)
        {
            // Keine Implementierung erforderlich f�r diesen Test
        }
    }

    // Testklasse
    public class BotEngineTests
    {
        [Fact]
        public void GetAnswer_ReturnsCorrectAnswer_ForExistingKeyword()
        {
            // Arrange
            var mockStorage = new MockStorage();
            var botEngine = new BotEngine(mockStorage);
            string keyword = "hallo";
            string expectedAnswer = "Hallo! Wie kann ich Ihnen helfen?";

            // Act
            string actualAnswer = botEngine.GetAnswer(keyword);

            // Assert
            Assert.Equal(expectedAnswer, actualAnswer);
        }
    }
}
